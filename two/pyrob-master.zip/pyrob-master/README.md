[![Build Status](https://travis-ci.org/mipt-cs-on-python3/pyrob.svg?branch=master)](https://travis-ci.org/mipt-cs-on-python3/pyrob)
